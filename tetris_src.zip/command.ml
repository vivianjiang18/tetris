type t = Left | Right | RotateCW | RotateCC | Drop | Quit

exception InvalidCommand